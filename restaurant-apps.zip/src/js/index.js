import "regenerator-runtime"; /* for async await transpile */
import "../styles/index.css";

// import js components
import "./components/RestaurantItem";

// Import data
import DATA from "../public/data/DATA.json";

// --- Start: Toggle app-bar
const toggleButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".app-bar__nav");

toggleButton.addEventListener("click", () => {
  const expanded =
    toggleButton.getAttribute("aria-expanded") === "true" || false;
  toggleButton.setAttribute("aria-expanded", !expanded);
  nav.classList.toggle("open");
});
// --- End: Toggle App-bar

// --- Start: Restaurant list
const restaurantListContainer = document.querySelector(".explore-restaurant");

// Populate restaurant items
DATA.restaurants.forEach((restaurant) => {
  const restaurantItem = document.createElement("restaurant-item");
  restaurantItem.id = restaurant.id;
  restaurantItem.name = restaurant.name;
  restaurantItem.description = restaurant.description;
  restaurantItem.pictureId = restaurant.pictureId;
  restaurantItem.city = restaurant.city;
  restaurantItem.rating = restaurant.rating;

  restaurantListContainer.appendChild(restaurantItem);
});
// --- End: Restaurant list
